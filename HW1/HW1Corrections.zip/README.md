Matt McDermott
COMP150 HW#1

Run file <main.py> with python3
Requires kalman.py as well as matplotlib and numpy libraries

